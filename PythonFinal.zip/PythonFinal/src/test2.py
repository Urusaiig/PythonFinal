'''
Created on Dec 4, 2018

@author: ss223023
'''
from tkinter import *


ui = 'Test'
t = Tk()
t.title("Poker Higher or Lower")
t.geometry("600x500")

def callback():
    print('Click!')    
    
def Higher():
    ui = 'h'
    
def Lower():
    ui = 'l'
    
def Same():
    ui = 's'
    
def quit():
    global root
    t.quit()
    


card1 = PhotoImage(file="10C.png")
card1 = card1.subsample(4,4)
c1 = Label(t, image=card1)

c1.grid(row=0, column=0, padx=20)





h = Button(t, text="Higher", command = Higher, anchor=CENTER)
h.config(height=5, width=15)
h.grid(row=1, column = 0, padx=20)

s = Button(t, text="Same", command = Same, anchor=CENTER)
s.config(height=5, width=15)
s.grid(row=1, column = 3)

l = Button(t, text="Lower", command = Lower, anchor=CENTER)
l.config(height=5, width=15)
l.grid(row=1, column = 4, padx=80)

    
b = Button(t, text = 'TEST', command = callback, anchor=CENTER)
b.grid(row=8, column=2, sticky=NSEW)

q = Button(t, text = 'Quit', command = quit, anchor=CENTER)
q.grid(row=9, column=2, sticky=NSEW)


lbl = Label(t, text=ui)
lbl.grid(row=3, column=1)



mainloop()